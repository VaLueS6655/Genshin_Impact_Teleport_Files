Sup. teleport pack created by zxcreepz ._.'

i tried to make it as legit as possible, so some chests will be divided into parts (c20.1 -> c20.2 etc)

also pack was based on: https://www.youtube.com/watch?v=XGL_JwNKJtM&ab_channel=KyoStinV


!!! U NEED COMPETE PRE-REQUIREMENTS (desc) TO GET 100% REGION !!!


also u dont understand something - u can watch video and try to find your problematic chest there.
Before use tp better to compleate main questline (4 lvl of the plate and other).




Some chests marked like [afk] and [afk vac]
That means you can collect them AFK (wow) with autotreasure ( [afk] ), and collect
afk with turned ON mob vacuum and killaura. BUT i dont reccomend to use this pack like this. but u can.







if u have any additions or anything else - write DMs zxcreepz#0001.
 
gl ;)
